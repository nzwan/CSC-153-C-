﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 *02/15/19 
 * Nicholas A. Zwan
 * This program generates a random addition problem and asks the user to solve it. 
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {   //Begi do while loop
            bool exit = false;
            do
            {   //Generate Menu
                Console.WriteLine("1.Run Program");
                Console.WriteLine("2.Exit");
                string input = Console.ReadLine();
                if (input == "1")
                {
                    
                    int userAnswer; //To hold user answer
                    Random rand = new Random(); // Used to create random numbers
                    int num1 = rand.Next(100);
                    Console.WriteLine($"num1 is {num1}");
                    int num2 = rand.Next(100);
                    Console.WriteLine($"num2 is {num2}");
                    Console.WriteLine("");
                    //Present user with addition Problem
                    Console.WriteLine($"Solve the following problem {num1} + {num2} = ? ");
                    input = Console.ReadLine();
                    int.TryParse(input, out userAnswer); //Convert string to int
                    int answer = num1 + num2; //Create answer variable

                    //Conditionals to return string based on User Input
                    if (userAnswer == answer)
                    {
                        Console.WriteLine("Correct");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Incorrect.");
                        Console.ReadLine();
                    }
                }
                else if (input == "2") // Allow user to exit the program. 
                {
                    exit = true;

                }

                Console.ReadLine(); //Read all WriteLines



            } while (exit == false); //Finish do while loop
        }

    }
}
