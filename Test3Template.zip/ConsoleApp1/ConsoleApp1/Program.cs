﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        const int SIZE = 5;
        static void Main(string[] args)
        {
            bool exit = false;
            

            do
            {
                string[] names = new string[SIZE];
                List<int> ages = new List<int>();


                //DisplayMenu();
                string input = DisplayMenu();

                if (input == "1")
                {
                    //TODO
                    Console.WriteLine("1");
                    AddNames (ref names);
                }
                else if (input == "2")
                {
                    //TODO
                    Console.WriteLine("2");
                    ages = AddAges();
                  
                }
                else
                {
                    exit = true;
                }


            } while (exit == false);
        }

        public static List<int> AddAges()
        {
            List<int> output;
            return output;
        }

        public static void AddNames(ref string[] names)
        {
            //TODO Add Names
            for (int count = 0; count < names.Length; count++) 
            {
                
            }
            
        }

        

        public static string DisplayMenu()
            {

                Console.WriteLine("1. 1");
                Console.WriteLine("2. 2");
                Console.WriteLine("1/2 > ");
                string output = Console.ReadLine();

                return output;
            }
        }
    }
    

