﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Nicholas A. Zwan
//CSC 153 Test (Revised)
//This program will allow a user to enter as many grades
//as they would like and calculat ethe average of those
//grades and return a letter grade that matches the average.

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Do while Loop
            bool exit = false;
            do
            {
                double sum = 0;
                double n = 0;
                double average = sum / n;

                //Create Menu
                Console.WriteLine("1. Enter grades and calculate average ");
                Console.WriteLine("2. Get Average");
                Console.WriteLine("3. Exit ");
                string input = Console.ReadLine();

                //Menu option 1 accepts input
                if (input == "1")
                {
                    Console.WriteLine("Enter the number of grades ?");
                    Console.WriteLine("");
                    Console.WriteLine("Enter your grades");


                    while (!double.TryParse(Console.ReadLine(), out n))


                        for (int i = 0; i < n; i++)
                        {
                            double num = double.Parse(Console.ReadLine()); //parse double
                            sum += num;
                            Console.WriteLine("");
                        }

                }
                //Decision structure for return of letter grade
                else if (input == "2")
                    if (average < 60)
                    {
                        Console.WriteLine("Your average is " + average + " which is an F");
                        Console.ReadLine();
                    }


                    else if (average <= 70)
                    {
                        Console.WriteLine("Your average is " + average + " which is a C");
                        Console.ReadLine();
                    }
                    else if (average <= 80)
                    {
                        Console.WriteLine("Your average is " + average + " which is a B");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Your average is " + average + " which is an A");
                        Console.ReadLine();
                        //Console.WriteLine(sum);
                        Console.ReadLine();


                    }



                else if (input == "3") //Allow user to exit program.
                {
                    exit = true;
                }


            } while (exit == false);
        }
    }
}


