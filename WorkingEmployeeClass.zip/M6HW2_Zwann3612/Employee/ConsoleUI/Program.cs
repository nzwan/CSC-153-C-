﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1; //Need to rename to HRLibrary 

/*
 * 05/10/19
 * CSC 153
 * Nicholas A. Zwam
 * This program simply creates a class library and the employee class.
 */ 

namespace ConsoleUI
{
    class Program

    {

        static void Main(string[] args)

        {

            Employee Employee = new Employee();
            

            bool exit = false;

            do {
                StandardMessages.DisplayMainMenu();
                switch (Console.ReadLine())
                {
                    case "1":
                        Employee.GetEmployeeInfo(Employee);
                        break;
                    case "2":
                        Employee.DisplayEmployeeInfo(Employee);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        StandardMessages.DisplayMenuError();
                        break;
                }
                

            } while (exit == false);
        }
    }
}
