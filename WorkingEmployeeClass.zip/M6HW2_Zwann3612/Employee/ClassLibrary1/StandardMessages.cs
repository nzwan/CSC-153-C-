﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class StandardMessages
    {
        public static void DisplayMainMenu()
        {
            Console.WriteLine("1. Get Employee info.");
            Console.WriteLine("2. Display Employee info.");
            Console.WriteLine("3. Exit");
            Console.Write("1/2/3 =>");
        }
        public static void DisplayMenuError()
        {
            Console.WriteLine("Not a valid choice!");
            Console.WriteLine("");
        }

    }
}
