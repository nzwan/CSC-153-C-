﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Employee
    {



        private string _name;
        private int _idNumber;
        private string _department;
        private string _position;
        //create default
        public Employee()
        {
            Name = "";
            IDNumber = 0;
            Department = "";
            Position = "";


        }
        //Custom
        public Employee(string name, int idNumber, string department, string position)
        {
            Name = name;
            IDNumber = idNumber;
            Department = department;
            Position = position;

        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int IDNumber
        {
            get
            {
                return _idNumber;
            }

            set
            {
                _idNumber = value;
            }
        }

        public string Department
        {
            get
            {
                return _department;
            }

            set
            {
                _department = value;
            }
        }

        public string Position
        {
            get
            {
                return _position;
            }

            set
            {
                _position = value;
            }
        }

            public static void GetEmployeeInfo(Employee input)
        {
            

            Console.Write("What is the employees name?");
            Console.WriteLine("");
            input.Name = Console.ReadLine();
            Console.WriteLine("");


            Console.Write("What is the employees ID#?");
            Console.WriteLine("");
            input.IDNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("");


            Console.Write("What is the employees Department?");
            Console.WriteLine("");
            input.Department = Console.ReadLine();
            Console.WriteLine("");


            Console.Write("What is the employees position?");
            Console.WriteLine("");
            input.Position = Console.ReadLine();
            Console.WriteLine("");



        }

        public static void DisplayEmployeeInfo(Employee input)
        {
            
            Console.WriteLine($"The Employees name is {input.Name}, their ID number is {input.IDNumber}, they operate out of the {input.Department}" +
                $" department, and they hold the position of {input.Position}.");
            Console.WriteLine("");
            Console.ReadLine();
            
        }

        }

    }





