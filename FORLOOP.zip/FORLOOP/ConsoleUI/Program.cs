﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            //do
            //{
            //    Console.WriteLine("1. Run program");
            //    Console.WriteLine("2. Exit");
            //    Console.Write("Enter 1 or 2 >");
            //    string input = Console.ReadLine();

            //    if( input == "1")
            //    {
            //        int count = 0;

            //        while(count < 5)
            //        {
            //            Console.WriteLine(count);
            //            count++;
            //        }
            //        Console.WriteLine("");

            //    }
            //    else if(input == "2")
            //    {
            //        exit = true;
            //    }
            //    else
            //    {
            //        Console.WriteLine("Not a choice");
            //        Console.WriteLine("");
            //    }
            //} while (exit == false);    


            do
            {
                Console.WriteLine("1. Run program");
                Console.WriteLine("2. Exit");
                Console.Write("Enter 1 or 2 >");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("This program will count from 0 to your number choice");
                    Console.WriteLine("What number? >");
                    input = Console.ReadLine();

                    int userCount = 0;

                    if (int.TryParse(input, out userCount))
                    {
                        for(int num = 0; num < userCount; num++)
                        {
                            Console.WriteLine($"Number {num}");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Not a Number!");
                    }
                    
                    
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not a choice");
                    Console.WriteLine("");
                }
            } while (exit == false);



        }
    }
}
