﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalGrades = 0;
            int grade = 0;
            int numberOfGrades = 0;
            bool exit = false;

            do
            {
                Console.WriteLine("1. Enter Grades");
                Console.WriteLine("2. Get Average");
                Console.WriteLine("3. Exit");
                Console.Write("1/2/3");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("How many grades do you wish to enter?");
                    Console.WriteLine("Enter a whole number >");
                    input = Console.ReadLine();
                    if (int.TryParse(input, out numberOfGrades))
                    {
                        for (int count = 1; count <= numberOfGrades; count++)
                        {
                            Console.Write($"Enter Grade{count} rounded to nearest whole number >");
                            input = Console.ReadLine();

                            if(int.TryParse(input, out grade))
                            {
                                totalGrades += grade;
                            }
                            else
                            {
                                Console.WriteLine("Not a proper grade.");
                            }

                        }
                    }
                    else
                    {
                        Console.WriteLine("Not a good number.");
                    }

                }
                else if (input == "2")
                {
                    double average = totalGrades / numberOfGrades;

                    if (average > 90)
                    {
                        Console.WriteLine($"Your average was {average}");
                        Console.WriteLine("You made an A.");
                    }
                    else if (average > 80)
                    {
                        Console.WriteLine($"Your average was {average}");
                        Console.WriteLine("You made a B.");
                    }
                    else if (average > 70)
                    {
                        Console.WriteLine($"Your average was {average}");
                        Console.WriteLine("You made a C.");
                    }
                    else if (average > 60)
                    {
                        Console.WriteLine($"Your average was {average}");
                        Console.WriteLine("You made a D.");
                    }
                    else
                     
                    { 
                        Console.WriteLine($"Your average was {average}");
                        Console.WriteLine("You made an F.");
                    }

                }
                else if (input == "3") 
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option. Try again");
                }

            } while (exit == false);
        }
    }
}
