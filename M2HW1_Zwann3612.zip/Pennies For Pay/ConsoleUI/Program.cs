﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 02/15/19
 * Nicholas A. Zwan 
 * This program accepts input and calculates users pay. 
 */ 

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {   
                //Generate menu
                Console.WriteLine("1.Run Program");
                Console.WriteLine("2. Exit");
                string input = Console.ReadLine();

                //Conditionals for Menu
                if (input == "1")
                Console.WriteLine("Enter number of days worked:");
                input = Console.ReadLine();

                //Initialize Variables
                int days;
                int pennies = 0;

                if (int.TryParse(input, out days))
                {
                    //Generate accumulator 
                    for (int i = 0; i < days; pennies += (int)1 << i++) ;

                    //Display results and format output.
                    Console.WriteLine("You earned {0:C}", pennies / 100.0);
                }

                else if (input == "2")
                {
                    exit = true;
                }
               // else
              //  {
                   // Console.WriteLine("Not a valid option.");
                   // Console.ReadLine();
               // }
            } while (exit == false);
            
        }
    }
}
