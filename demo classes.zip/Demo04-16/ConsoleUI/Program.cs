﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 student = new Class1();

            student.FirstName = "Tom";
            student.MiddleName = "J";
            student.LastName = "Blake";
            student.Age = 18;

            Console.WriteLine($"{student.FirstName} {student.MiddleName} {student.LastName} {student.Age}");

            Class1 student2 = new Class1("Steven", "P", "Blake", 21);
            Console.WriteLine($"{student2.FirstName} {student2.MiddleName} {student2.LastName} {student2.Age}.");

            student2.SubtractAge();
            Console.WriteLine($"{student2.FirstName} {student2.MiddleName} {student2.LastName} {student2.Age}.");


            Console.ReadLine();

        }
    }
}
