﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        private string _firstName;
        private string _lastName;
        private int _age;

        public Class1()
        {
            FirstName = "";
            MiddleName = "";
            LastName = "";
            Age = 0;
        }

        public Class1(string firstName, string middleName, string lastName, int age)
        {
           FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Age = age;

        }

        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }



             public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

             public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }

        }
        public void SubtractAge()
        {
            Age = Age -1;
        }
        public string MiddleName { get; set; }


        }

    }

