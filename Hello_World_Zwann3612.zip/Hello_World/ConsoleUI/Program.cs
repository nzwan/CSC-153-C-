﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 1/17/19
 * CSC-153
 * Nick Zwan
 * Hello World Intro
 */

namespace ConsoleUI
{
    class Program
    {   
        // TODO Program input and processing

        static void Main(string[] args)
        
        {
            // Accepts Strings to be read.
            Console.WriteLine("Hello World.");
            Console.WriteLine("");
            Console.WriteLine("My Name is Nick Zwan!");
            Console.WriteLine("");
            Console.WriteLine("I am hoping to develop a greater understanding of C# so that I can expand my programming arsenal.");
            Console.WriteLine("");
            Console.WriteLine("I have currently taken Intro to Programming and Logic, Python, Advanced Python, and Database programming 1.");
            Console.WriteLine("");
            Console.WriteLine("We covered all of the subjects provided in the list. Ill never try to copy and paste again. I still have a long way to go!");
            // Reads all previously written Strings.
            Console.ReadLine();
        }
    }
}
