﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            List<int> ages = new List<int>();


            do
            {

                DisplayMainMenu();

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        
                        AskforAge(ref ages);
                        break;
                    case "2":
                        DisplayAges(ref ages);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid option. Try again.");
                        break;
                }

            } while (exit == false);
        }

        private static void DisplayAges(ref List<int> ages)
        {
            foreach (int age in ages)
            {
                Console.WriteLine(age);
            }
        }

        public static void AskforAge(ref List<int> ages)
        {
            bool exitAge = false;
            int age;

            

            do
            {
                Console.WriteLine("Enter the age or -1 to exit.");
                string input = Console.ReadLine();

                if(int.TryParse(input, out age))
                {
                    if (input != "-1")
                    {
                        AddAgeToList(age, ages);
                    }
                    else
                    {
                        exitAge = true;
                    }
                }
                else
                {
                    Console.WriteLine("Not a good number!");
                }

            } while (exitAge == false);

        }

        private static void AddAgeToList(int age, List<int> ages)
        {
            ages.Add(age);
        }

        public static void DisplayMainMenu()
        {
            Console.WriteLine("1. Enter Ages.");
            Console.WriteLine("2. Display Ages.");
            Console.WriteLine("3. Exit.");
            Console.Write("Enter 1/2/3 > ");
        }
    }
}
