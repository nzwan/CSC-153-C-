﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 3/7/2019
 * CSC-153
 * Grace Ross
 * This program lets the user choose from a menu to enter names and grades, and after grades have been entered, the user can select option 3 to see the average of the 
 * grades previously entered. I used a do-while loop for the program to run in and had if-else-if-else statements, along with a for loop. An accumulator is used to hold 
 * the total of the grades entered and a calculation is done to find the average of the grades. After the grades are entered the user is instructed to select option 3 from
 * the menu to see the names entered, the average grade of the class along with the letter grade.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            string input;
            int num, gradeA = 90, gradeB = 80, gradeC = 70, gradeD = 60, grades = 0, average = 0;
            // I set the SIZE to six, so that then I ran the for loop for the array, I could start the index at 1 and have the number outputted with the enter name prompt.
            const int SIZE= 6;

            // Declaring the arrary for names.
            string[] names = new string[SIZE];

            // Declaring the list for grades
            List<int> holdGrades = new List<int>();
 
            do
            {
                Console.WriteLine("1. Enter Names");
                Console.WriteLine("2. Enter Grades");
                Console.WriteLine("3. Get Average");
                Console.WriteLine("4. Exit");
                Console.Write("Enter 1, 2, 3, or 4 > ");
                input = Console.ReadLine();

                if (input == "1")
                {
                    for (int index = 1; index < SIZE; index++)
                    {
                        Console.Write($"Enter name {index}>");
                        input = Console.ReadLine();

                        names[index] = input;
                    }
                    Console.WriteLine("Go to Enter Grades.\n");
                }
                else if (input == "2")
                {
                    Console.Write("How many grades would you like to enter? > ");
                    input = Console.ReadLine();

                    if (int.TryParse(input, out num))
                    {
                        for (int count = 1; count <= num; count++)
                        {
                            Console.Write("Enter a grade: ");
                            input = Console.ReadLine();
                            if (int.TryParse(input, out grades))
                            {
                                holdGrades.Add(grades);

                                int total = 0;
                                foreach (int value in holdGrades)
                                {
                                    total += value;
                                }
                                average = total / holdGrades.Count();
                            }
                            else
                            {
                                Console.WriteLine("Please enter a number for a grade.");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Not a number!");
                    }

                    Console.WriteLine("Go to Get Average option in Menu to see the average of the grades entered.\n");
                }
                else if (input == "3")
                {
                    Console.WriteLine("Names Entered:");
                    foreach (string name in names)
                    {
                        Console.WriteLine(name);
                    }

                    if (average >= gradeA)
                    {
                        Console.WriteLine($"The grade average for the class is {average} which is an A.\n");
                    }
                    else if (average >= gradeB && average < gradeA)
                    {
                        Console.WriteLine($"The grade average for the class is {average} which is a B.\n");
                    }
                    else if (average >= gradeC && average < gradeB)
                    {
                        Console.WriteLine($"The grade average for the classis {average} which is a C.\n");
                    }
                    else if (average >= gradeD && average < gradeC)
                    {
                        Console.WriteLine($"The grade average for the class is {average} which is a D.\n");
                    }
                    else
                    {
                        Console.WriteLine($"The grade average for the class is {average} which is an F.\n");
                    }

                }
                else if (input == "4")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not a Choice! \n");
                }
            }
            while (exit == false);
        }
    }
}
