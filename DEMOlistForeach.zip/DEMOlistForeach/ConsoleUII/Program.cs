﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUII
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = new List<int>();

            List<string> words = new List<string>() { "One", "Two", "Three" };

            numbers.Add(1);
            numbers.Add(2);
            numbers.Add(3);
            numbers.Add(4);
            numbers.Add(5);

            Console.WriteLine(numbers.Count);



            numbers.Insert(3, 100);

            Console.WriteLine("After Insert");
            for(int index = 0; index < numbers.Count(); index++)
            {
                Console.WriteLine(numbers[index]);
            }
            numbers.Remove(100);
            Console.WriteLine("After Remove value 100");

             for(int index = 0; index < numbers.Count(); index++)
            {
                Console.WriteLine(numbers[index]);
            }

            numbers.RemoveAt(3);
            Console.WriteLine("After removeAt 3");
            for (int index = 0; index < numbers.Count(); index++)
            {
                Console.WriteLine(numbers[index]);
            }

            Console.WriteLine("using the for each loop on words");
            foreach(var value in numbers)
            {
                Console.WriteLine(value);
            }

            Console.ReadLine();

        }
    }
}
