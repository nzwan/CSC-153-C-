﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class GetGrades
    {
        //Get grades and add to  a list
        public static void EnterGrades()
        {
            List<int> holdGrades = new List<int>();
            int num;
            int grades = 0, average = 0;


            string input = Console.ReadLine();

            Console.Write("How many grades would you like to enter? > ");
            input = Console.ReadLine();

            if (int.TryParse(input, out num))
            {
                for (int count = 1; count <= num; count++)
                {
                    Console.Write("Enter a grade: ");
                    input = Console.ReadLine();
                    if (int.TryParse(input, out grades))
                    {
                        holdGrades.Add(grades);

                        int total = 0;
                        foreach (int value in holdGrades)
                        {
                            total += value;
                        }
                        average = total / holdGrades.Count();

                    }
                    else
                    {
                        Console.WriteLine("Please enter a number for a grade.");

                    }
                }
            }
            else
            {
                Console.WriteLine("Not a valid number.");
            }
        }
    }
}
