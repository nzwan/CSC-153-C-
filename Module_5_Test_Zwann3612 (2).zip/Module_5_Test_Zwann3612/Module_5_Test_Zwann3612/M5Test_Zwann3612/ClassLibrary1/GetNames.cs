﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class GetNames
    {
        //Get names and add to a list
        public static void EnterNames()
        {
            const int SIZE = 6;
            string[] names = new string[SIZE];
            string input = Console.ReadLine();
           
            
            for (int index = 1; index < SIZE; index++)
            {
                Console.Write($"Enter name {index}>");
                input = Console.ReadLine();

                names[index] = input;
            }
        }
    }
}

