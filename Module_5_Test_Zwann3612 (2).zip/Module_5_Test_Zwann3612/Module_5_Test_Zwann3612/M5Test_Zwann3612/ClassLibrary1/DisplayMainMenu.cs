﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class DisplayMainMenu
    {
        public static string MainMenu()
        {
            //Menu
            Console.WriteLine("1. Enter Names");
            Console.WriteLine("2. Enter Grades");
            Console.WriteLine("3. Get Average");
            Console.WriteLine("4. Exit");
            Console.Write("Enter 1, 2, 3, or 4 > ");
            string output = Console.ReadLine();
            return output;

            
        }
    }
}
