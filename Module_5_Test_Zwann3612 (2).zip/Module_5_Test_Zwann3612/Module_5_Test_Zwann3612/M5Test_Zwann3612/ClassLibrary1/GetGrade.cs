﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
   public class GetGrade
    {
        public static void GetAverage(ref int average)
        {
            //Declare variables
            int gradeA = 90, gradeB = 80, gradeC = 70, gradeD = 60;
            Console.WriteLine("Names Entered:");

            //TODO foreach (string name in names)
            // {
            // Console.WriteLine(name);
            // }

            // Decision structure
            if (average >= gradeA)
            {
                Console.WriteLine($"The grade average for the class is {average} which is an A.\n");
            }
            else if (average >= gradeB && average < gradeA)
            {
                Console.WriteLine($"The grade average for the class is {average} which is a B.\n");
            }
            else if (average >= gradeC && average < gradeB)
            {
                Console.WriteLine($"The grade average for the classis {average} which is a C.\n");
            }
            else if (average >= gradeD && average < gradeC)
            {
                Console.WriteLine($"The grade average for the class is {average} which is a D.\n");
            }
            else
            {
                Console.WriteLine($"The grade average for the class is {average} which is an F.\n");
            }
           
                
        }
    }
}
