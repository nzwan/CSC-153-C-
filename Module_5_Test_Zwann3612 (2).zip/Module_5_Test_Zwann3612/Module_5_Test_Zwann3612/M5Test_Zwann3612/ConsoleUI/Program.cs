﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

/*Nicholas A. Zwan
 * CSC 153
 * Module 4 Test
 * 03/27/19
 * This program will accept names and grades into a list and then return those values
 * grades will be averaged and a letter grade will be determined and returned.
 */ 

namespace ConsoleUI
{
  class Program

    { 
        
        
    


        public static void Main(string[] args)
        {
            
            bool exit = false;
            string input = Console.ReadLine();
            do
            {
              DisplayMainMenu.MainMenu();
             

                

                if (input == "1")
                {

                    GetNames.EnterNames();

                }
                else if (input == "2")
                {
                  GetGrades.EnterGrades();
                }
                else if (input == "3")
                {
                   
                }

                else
                {
                    exit = true;
                }
                

                
            } while (exit == false);





        }
    }
}
